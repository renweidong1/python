# GoBang
基于PyQt5的五子棋编程（人机对弈）
